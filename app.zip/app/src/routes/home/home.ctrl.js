"use strict";

const http = require("http");
const express = require("express");
const app = express();
var request = require('request');

const output = {
    home: (req, res) => {
        res.render("home/index");
    },
    
    login: (req, res) => {
        res.render("home/login");
    },
};

const options = {
    hostname:'localhost',
    port:'3000',
    path:'/api/member/login',
    method:'POST',
    body:{
        'Content-Type':'application/json',
        'priority':'high'
    },
    json:true
}

const data = JSON.stringify({
    name : "sohyun"
})

const process = {
    login: (req, res) => {
        http.request(options, function(err, req, res) {
            let body = '';
            console.log('Status Code:', res.statusCode);

            res.on('data', (chunk)=>{
                body += chunk;
            })
        
            res.on('end', () => {
                console.log('body:', JSON.parse(body));
            })

            if(req.body === 'ok')
            {
                res.send("dd");
                console.log("로그인 성공");
            }
        });
    },
};

module.exports = app;

module.exports = {
    output,
    process,
};